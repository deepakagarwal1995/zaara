<?php $__env->startSection('content'); ?>
    <div class="homebanner inbanner">
        <div class="container">
            <h1 class="inhead"><?php echo e($blog->title); ?></h1>
        </div>
    </div>
    <div class="bradcrum">
        <div class="container">
            <ul itemscope="" itemtype="http://schema.org/BreadcrumbList">
                <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem"><a itemprop="item"
                        href="hhttps://www.zaaratravels.in"> <span itemprop="name">Book Cab</span></a> »
                    <meta itemprop="position" content="1">
                </li>
                <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                    <h3 itemprop="item"> <span itemprop="name"><?php echo e($blog->title); ?></span></h3>
                    <meta itemprop="position" content="2">
                </li>
            </ul>
        </div>
    </div>


    <section id="latestUpdate">

        <div class="container">



            <div class="col-md-12">
                <div><?php echo $blog->descr; ?>

                </div>
            </div>


        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('visitors.layout', ['title' => $blog->title, 'descr' => $blog->sdescr], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u701348645/domains/zaaratravels.in/public_html/resources/views/visitors/page.blade.php ENDPATH**/ ?>