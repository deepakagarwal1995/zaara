<div class="mt-4 text-right">
    <?php if($items->hasPages()): ?>
        <nav aria-label="Page navigation example">
            <?php echo e($items->links('pagination::bootstrap-5')); ?>


        </nav>
    <?php endif; ?>
</div>
<?php /**PATH D:\php\zaara\resources\views/admin/inc/pagination.blade.php ENDPATH**/ ?>