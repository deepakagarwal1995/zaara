<?php $__env->startSection('content'); ?>
    <div class="homebanner inbanner">
        <div class="container">
            <h1 class="inhead"><?php echo e($blog->title); ?></h1>
        </div>
    </div>
    <div class="bradcrum">
        <div class="container">
            <ul itemscope="" itemtype="http://schema.org/BreadcrumbList">
                <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem"><a itemprop="item"
                        href="hhttps://www.zaaratravels.in"> <span itemprop="name">Book Cab</span></a> »
                    <meta itemprop="position" content="1">
                </li>
                <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                    <h3 itemprop="item"> <span itemprop="name"><?php echo e($blog->title); ?></span></h3>
                    <meta itemprop="position" content="2">
                </li>
            </ul>
        </div>
    </div>


    <section id="latestUpdate">

        <div class="container">
            <div class="brd_bot">
                <h1 class="mnpgHead"><span><?php echo e($blog->title); ?></span></h1>
                <p><?php echo e($blog->sdescr); ?></p>
            </div>

              <div class="clearfix PB20">
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <h2 class="page_head2 PB5"><?php echo e($blog->external_title); ?></h2>
                  <ul class="mumbadarList">
                    <?php $__currentLoopData = $butns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('page', $row->slug)); ?>"
                        title="<?php echo e($row->title); ?>"><?php echo e($row->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </ul>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <div class="siderates">
                    <div class="page_head2 PB10">Varanasi Taxi Fare Charts</div>
                        <!-- Varanasi local rates -->
                        <div id="localvaranasi"><table class="fare_tbl2" cellpadding="0" cellspacing="0" border="0" width="100%">
          <thead><tr>
          <th>Vehicle Type</th>
          <th>8Hrs 80km</th>
          <th>12Hrs 120km</th>
          <th>Extra HR/Km</th>
          </tr></thead>
          <tbody>
            <?php $__currentLoopData = $local_cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr><td><?php echo e($row->cab->title); ?></td><td><?php echo e($row->eight_hr); ?></td><td><?php echo e($row->twelve_hr); ?></td><td><?php echo e($row->extra_hr); ?>/Km</td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody></table></div>
                      <!-- Varanasi local rates -->
                  </div>
                </div>
              </div>
            <div class="col-md-12">
                <div><?php echo $blog->descr; ?>

                </div>
            </div>


        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('visitors.layout', ['title' => $blog->title, 'descr' => $blog->sdescr], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\zaara\resources\views/visitors/page.blade.php ENDPATH**/ ?>