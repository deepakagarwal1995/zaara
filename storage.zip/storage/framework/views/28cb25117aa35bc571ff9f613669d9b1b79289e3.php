<div class="mt-4 text-right">
    <?php if($items->hasPages()): ?>
        <nav aria-label="Page navigation example">
            <?php echo e($items->links('pagination::bootstrap-5')); ?>


        </nav>
    <?php endif; ?>
</div>
<?php /**PATH /home/u701348645/domains/zaaratravels.in/public_html/resources/views/admin/inc/pagination.blade.php ENDPATH**/ ?>