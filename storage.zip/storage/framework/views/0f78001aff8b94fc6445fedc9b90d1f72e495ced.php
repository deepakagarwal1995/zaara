<?php $__env->startSection('content'); ?>
<style>
     .success-icon {
            font-size: 50px;
            color: #28a745;
        }

        .success-message {
            font-size: 24px;
            color: #28a745;
            font-weight: bold;
            margin: 20px 0;
        }

        .details-box {
            text-align: left;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
        }

        .details-box h4 {
            margin-bottom: 15px;
            font-size: 18px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table th, table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #f0f0f0;
            font-weight: normal;
        }

        .btn {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
        }

        .btn:hover {
            background-color: #0056b3;
        }

</style>
    <section class="pageContent">
        <div class="container">
            <div class="success-icon">&#10004;</div>
            <div class="success-message">Payment Successful!</div>
            <p>Your payment has been processed successfully.</p>
          
            <div class="details-box">
                <h4>Payment Details</h4>
                <table>
                    <tr>
                        <th>Transaction ID:</th>
                        <td><?php echo e($update->txnid); ?></td>
                    </tr>
                    <tr>
                        <th>Amount Paid:</th>
                        <td>INR <?php echo e($update->payment); ?></td>
                    </tr>
                    <tr>
                        <th>Cab Details:</th>
                        <td><?php echo e($update->cab); ?>, <small><?php echo e($update->cabname); ?></small></td>
                    </tr>
                    <tr>
                        <th>Payer Name:</th>
                        <td><?php echo e($update->name); ?></td>
                    </tr>
                    <tr>
                        <th>Contact:</th>
                        <td><?php echo e($update->phone); ?></td>
                    </tr>
                </table>
            </div>
    
        </div>
    </section>
    <?php
    
  ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('visitors.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u701348645/domains/zaaratravels.in/public_html/resources/views/visitors/success.blade.php ENDPATH**/ ?>