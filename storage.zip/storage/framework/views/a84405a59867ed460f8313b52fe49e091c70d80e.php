<?php $__env->startSection('content'); ?>
    <div class="homebanner inbanner">
        <div class="container">
            <h1 class="inhead">Blogs</h1>
        </div>
    </div>
    <div class="bradcrum">
        <div class="container">
            <ul itemscope="" itemtype="http://schema.org/BreadcrumbList">
                <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem"><a itemprop="item"
                        href="hhttps://www.zaaratravels.in"> <span itemprop="name">Book Cab</span></a> »
                    <meta itemprop="position" content="1">
                </li>
                <li itemprop="itemListElement" itemscope="" itemtype="http://schema.org/ListItem">
                    <h3 itemprop="item"> <span itemprop="name">Blogs</span></h3>
                    <meta itemprop="position" content="2">
                </li>
            </ul>
        </div>
    </div>


    <section id="latestUpdate">

        <div class="container">


            <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div style="    padding: 10px;
    margin-bottom: 10px;">
                        <div class="latestpostbx" style="width: 100%">
                            <figure><a href="<?php echo e(route('blog_detail', $row->slug)); ?>" title="<?php echo e($row->img_alt); ?>"><img
                                        src="<?php echo e(Storage::url('blog/' . $row->img)); ?>" width="370" height="185"
                                        alt="<?php echo e($row->img_alt); ?>"></a></figure>
                            <div class="latestmCnt">
                                <h4><a href="<?php echo e(route('blog_detail', $row->slug)); ?>"><?php echo e($row->title); ?></a></h4>
                                <p>
                                <p><?php echo e($row->sdescr); ?>

                                    <a href="<?php echo e(route('blog_detail', $row->slug)); ?>" class="read-more"> <i
                                            class="ion-ios-arrow-right read-more-right"></i></a>
                                </p>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('visitors.layout', ['title' => 'Blogs | Zaara Tours & Travels', 'descr' => 'Blogs | Zaara Tours & Travels'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u701348645/domains/zaaratravels.in/public_html/resources/views/visitors/blog.blade.php ENDPATH**/ ?>