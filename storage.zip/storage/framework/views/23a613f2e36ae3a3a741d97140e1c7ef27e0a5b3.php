<?php $__env->startSection('content'); ?>
    <div class="page-title-box">

        <div class="d-flex align-items-sm-center flex-sm-row flex-column gap-2">
            <div class="flex-grow-1">
                <h4 class="font-18 mb-0"><?php echo e($title); ?> </h4>
            </div>

            <div class="text-end">
                <ol class="breadcrumb m-0 py-0">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>



                    <li class="breadcrumb-item active"><?php echo e($title); ?></li>
                </ol>
            </div>
        </div>



    </div>


    <div class="row">


        <div class="col-xl-12">
            <div class="card">
                <div class="card-header">

                    <?php echo $__env->make('admin.inc.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="card-body pt-2">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Address</th>
                                    <th>City</th>
                                    <th>License</th>
                                    <th>Insurance</th>

                                    <th>Vehicle Type</th>
                                    <th>Docs</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $currentPage = $items->currentPage() - 1;
                                    $currentPage = $currentPage * $items->perPage();

                                ?>

                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td scope="row"><?php echo e($loop->index + $currentPage + 1); ?></td>

                                        <td><?php echo e($row->name); ?><br>
                                             <?php echo e($row->phone); ?></td>
                                        <td><?php echo e($row->address); ?></td>
                                        <td><?php echo e($row->city); ?></td>
                                        <td>License: <?php echo e($row->license); ?><br>
                                            Registration: <?php echo e($row->registration); ?></td>
                                            <td>Manufacture: <?php echo e($row->year); ?><br>
                                                Insurance: <?php echo e($row->lisence_exp); ?></td>
                                                <td><?php echo e($row->cab->name); ?> (<?php echo e($row->cab->title); ?>)</td>
                                        <td><?php if($row->license_img!=''): ?><a target="_blank" href="<?php echo e(Storage::url('driver/' . $row->license_img)); ?>">Driver licence</a><?php endif; ?><br>
                                            <?php if($row->insuranse_img!=''): ?><a target="_blank" href="<?php echo e(Storage::url('driver/' . $row->insuranse_img)); ?>">Insurance Paper</a><?php endif; ?><br>
                                            <?php if($row->registration_img!=''): ?><a target="_blank" href="<?php echo e(Storage::url('driver/' . $row->registration_img)); ?>">RC Image</a><?php endif; ?>
                                        </td>

                                        <td>
                                            <?php if($row->status == 1): ?>
                                                <span class="badge bg-success">Active</span>
                                            <?php endif; ?>

                                            <?php if($row->status == 0): ?>
                                                <span class="badge bg-danger">Unactive</span>
                                            <?php endif; ?>

                                        </td>

                                        <td>
                                            <div class="d-flex">


                                            <?php if($row->status == 0): ?>
                                            <a href="<?php echo e(route('driver.status', $row->id,$row->status)); ?>"
                                                class="btn btn-success me-1">Approve</a>
                                            <?php endif; ?>





                                                <form action="<?php echo e(route('driver.destroy', $row->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit"
                                                        onclick="return confirm('Are You Sure You Want to Delete !!')"
                                                        class="btn btn-icon btn-danger">
                                                        <i class="ti ti-trash"></i>
                                                    </button>
                                                </form>
                                            </div>


                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <?php echo $__env->make('admin.inc.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <!-- end card body-->
            </div> <!-- end card -->
        </div><!-- end col-->
    </div>
    <!-- end row-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php\zaara\resources\views/admin/Drivers/index.blade.php ENDPATH**/ ?>